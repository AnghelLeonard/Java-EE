import {bootstrap}    from './resources/primeng/node_modules/angular2/platform/browser';
import {AppComponent} from './app.component';

bootstrap(AppComponent);