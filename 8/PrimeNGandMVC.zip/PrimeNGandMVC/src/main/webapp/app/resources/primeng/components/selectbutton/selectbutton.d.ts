/// <reference path="../../typedefinition/primeui.d.ts" />
import { ElementRef, SimpleChange, EventEmitter } from 'angular2/core';
import { SelectItem } from '../api/selectitem';
export declare class SelectButton {
    private el;
    initialized: boolean;
    options: SelectItem[];
    tabindex: number;
    multiple: boolean;
    value: any;
    valueChange: EventEmitter<any>;
    onChange: EventEmitter<any>;
    stopNgOnChangesPropagation: boolean;
    constructor(el: ElementRef);
    ngAfterViewInit(): void;
    ngOnChanges(changes: {
        [key: string]: SimpleChange;
    }): void;
    ngOnDestroy(): void;
}
