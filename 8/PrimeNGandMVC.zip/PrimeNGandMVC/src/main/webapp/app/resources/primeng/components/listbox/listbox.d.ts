/// <reference path="../../typedefinition/primeui.d.ts" />
import { ElementRef, SimpleChange, EventEmitter } from 'angular2/core';
import { SelectItem } from '../api/selectitem';
export declare class Listbox {
    private el;
    initialized: boolean;
    options: SelectItem[];
    value: any;
    multiple: boolean;
    scrollHeight: number;
    customContent: boolean;
    style: string;
    styleClass: string;
    valueChange: EventEmitter<any>;
    onChange: EventEmitter<any>;
    stopNgOnChangesPropagation: boolean;
    constructor(el: ElementRef);
    ngAfterViewInit(): void;
    ngOnChanges(changes: {
        [key: string]: SimpleChange;
    }): void;
    ngOnDestroy(): void;
}
