export declare class ProgressBar {
    value: any;
}
