/// <reference path="../../typedefinition/primeui.d.ts" />
import { ElementRef, SimpleChange } from 'angular2/core';
export declare class Carousel {
    private el;
    numVisible: number;
    firstVisible: number;
    headerText: string;
    effectDuration: any;
    circular: boolean;
    breakpoint: number;
    responsive: boolean;
    autoplayInterval: number;
    easing: string;
    pageLinks: number;
    style: string;
    styleClass: string;
    initialized: boolean;
    carouselElement: any;
    constructor(el: ElementRef);
    ngAfterContentInit(): void;
    ngOnChanges(changes: {
        [key: string]: SimpleChange;
    }): void;
    ngOnDestroy(): void;
}
