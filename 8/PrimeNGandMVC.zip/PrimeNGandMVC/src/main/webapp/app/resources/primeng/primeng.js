System.register(['./components/api/selectitem', './components/api/message', './components/accordion/accordion', './components/accordion/accordiontab', './components/button/button', './components/carousel/carousel', './components/chart/barchart/barchart', './components/chart/doughnutchart/doughnutchart', './components/chart/linechart/linechart', './components/chart/piechart/piechart', './components/chart/polarareachart/polarareachart', './components/chart/radarchart/radarchart', './components/checkbox/checkbox', './components/dialog/dialog', './components/fieldset/fieldset', './components/galleria/galleria', './components/growl/growl', './components/inputswitch/inputswitch', './components/inputtext/inputtext', './components/inputtextarea/inputtextarea', './components/listbox/listbox', './components/messages/messages', './components/panel/panel', './components/password/password', './components/progressbar/progressbar', './components/radiobutton/radiobutton', './components/rating/rating', './components/selectbutton/selectbutton', './components/spinner/spinner', './components/tabview/tabview', './components/tabview/tabpanel', './components/togglebutton/togglebutton'], function(exports_1) {
    function exportStar_1(m) {
        var exports = {};
        for(var n in m) {
            if (n !== "default") exports[n] = m[n];
        }
        exports_1(exports);
    }
    return {
        setters:[
            function (selectitem_1_1) {
                exportStar_1(selectitem_1_1);
            },
            function (message_1_1) {
                exportStar_1(message_1_1);
            },
            function (accordion_1_1) {
                exportStar_1(accordion_1_1);
            },
            function (accordiontab_1_1) {
                exportStar_1(accordiontab_1_1);
            },
            function (button_1_1) {
                exportStar_1(button_1_1);
            },
            function (carousel_1_1) {
                exportStar_1(carousel_1_1);
            },
            function (barchart_1_1) {
                exportStar_1(barchart_1_1);
            },
            function (doughnutchart_1_1) {
                exportStar_1(doughnutchart_1_1);
            },
            function (linechart_1_1) {
                exportStar_1(linechart_1_1);
            },
            function (piechart_1_1) {
                exportStar_1(piechart_1_1);
            },
            function (polarareachart_1_1) {
                exportStar_1(polarareachart_1_1);
            },
            function (radarchart_1_1) {
                exportStar_1(radarchart_1_1);
            },
            function (checkbox_1_1) {
                exportStar_1(checkbox_1_1);
            },
            function (dialog_1_1) {
                exportStar_1(dialog_1_1);
            },
            function (fieldset_1_1) {
                exportStar_1(fieldset_1_1);
            },
            function (galleria_1_1) {
                exportStar_1(galleria_1_1);
            },
            function (growl_1_1) {
                exportStar_1(growl_1_1);
            },
            function (inputswitch_1_1) {
                exportStar_1(inputswitch_1_1);
            },
            function (inputtext_1_1) {
                exportStar_1(inputtext_1_1);
            },
            function (inputtextarea_1_1) {
                exportStar_1(inputtextarea_1_1);
            },
            function (listbox_1_1) {
                exportStar_1(listbox_1_1);
            },
            function (messages_1_1) {
                exportStar_1(messages_1_1);
            },
            function (panel_1_1) {
                exportStar_1(panel_1_1);
            },
            function (password_1_1) {
                exportStar_1(password_1_1);
            },
            function (progressbar_1_1) {
                exportStar_1(progressbar_1_1);
            },
            function (radiobutton_1_1) {
                exportStar_1(radiobutton_1_1);
            },
            function (rating_1_1) {
                exportStar_1(rating_1_1);
            },
            function (selectbutton_1_1) {
                exportStar_1(selectbutton_1_1);
            },
            function (spinner_1_1) {
                exportStar_1(spinner_1_1);
            },
            function (tabview_1_1) {
                exportStar_1(tabview_1_1);
            },
            function (tabpanel_1_1) {
                exportStar_1(tabpanel_1_1);
            },
            function (togglebutton_1_1) {
                exportStar_1(togglebutton_1_1);
            }],
        execute: function() {
        }
    }
});
//# sourceMappingURL=primeng.js.map