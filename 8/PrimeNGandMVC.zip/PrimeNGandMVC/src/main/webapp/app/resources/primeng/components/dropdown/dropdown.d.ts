/// <reference path="../../typedefinition/primeui.d.ts" />
import { ElementRef, SimpleChange, EventEmitter } from 'angular2/core';
import { SelectItem } from '../api/selectitem';
export declare class Dropdown {
    private el;
    options: SelectItem[];
    value: any;
    valueChange: EventEmitter<any>;
    onChange: EventEmitter<any>;
    scrollHeight: number;
    customContent: boolean;
    filter: boolean;
    filterMatchMode: string;
    style: string;
    styleClass: string;
    initialized: boolean;
    selectElement: JQuery;
    constructor(el: ElementRef);
    ngAfterViewInit(): void;
    ngOnChanges(changes: {
        [key: string]: SimpleChange;
    }): void;
    ngOnDestroy(): void;
}
