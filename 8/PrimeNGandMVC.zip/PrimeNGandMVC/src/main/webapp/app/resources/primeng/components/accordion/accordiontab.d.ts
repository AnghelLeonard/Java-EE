/// <reference path="../../typedefinition/primeui.d.ts" />
import { Accordion } from './accordion';
export declare class AccordionTab {
    header: string;
    initialized: boolean;
    constructor(tabview: Accordion);
}
