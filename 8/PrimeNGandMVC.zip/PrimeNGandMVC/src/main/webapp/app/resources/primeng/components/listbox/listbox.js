/// <reference path="../../typedefinition/primeui.d.ts" />
System.register(['angular2/core'], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var Listbox;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            Listbox = (function () {
                function Listbox(el) {
                    this.el = el;
                    this.valueChange = new core_1.EventEmitter();
                    this.onChange = new core_1.EventEmitter();
                    this.initialized = false;
                }
                Listbox.prototype.ngAfterViewInit = function () {
                    var _this = this;
                    jQuery(this.el.nativeElement.children[0].children[0].children[0]).puilistbox({
                        value: this.value,
                        scrollHeight: this.scrollHeight,
                        multiple: this.multiple,
                        enhanced: true,
                        style: this.style,
                        styleClass: this.styleClass,
                        change: function (event, ui) {
                            _this.stopNgOnChangesPropagation = true;
                            _this.onChange.next({ originalEvent: event, value: ui.value });
                            if (_this.multiple) {
                                var values = [];
                                for (var i = 0; i < ui.index.length; i++) {
                                    values.push(_this.options[ui.index[i]].value);
                                }
                                _this.valueChange.next(values);
                            }
                            else {
                                _this.valueChange.next(_this.options[ui.index].value);
                            }
                        }
                    });
                    this.initialized = true;
                };
                Listbox.prototype.ngOnChanges = function (changes) {
                    if (this.initialized) {
                        for (var key in changes) {
                            if (key == 'value' && this.stopNgOnChangesPropagation) {
                                this.stopNgOnChangesPropagation = false;
                                continue;
                            }
                            jQuery(this.el.nativeElement.children[0].children[0].children[0]).puilistbox('option', key, changes[key].currentValue);
                        }
                    }
                };
                Listbox.prototype.ngOnDestroy = function () {
                    jQuery(this.el.nativeElement.children[0].children[0].children[0]).puilistbox('destroy');
                    this.initialized = false;
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Array)
                ], Listbox.prototype, "options", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object)
                ], Listbox.prototype, "value", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean)
                ], Listbox.prototype, "multiple", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Number)
                ], Listbox.prototype, "scrollHeight", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean)
                ], Listbox.prototype, "customContent", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], Listbox.prototype, "style", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], Listbox.prototype, "styleClass", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], Listbox.prototype, "valueChange", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], Listbox.prototype, "onChange", void 0);
                Listbox = __decorate([
                    core_1.Component({
                        selector: 'p-listbox',
                        template: "\n        <div class=\"ui-listbox ui-inputtext ui-widget ui-widget-content ui-corner-all\">\n            <div class=\"ui-helper-hidden-accessible\">\n                <select>\n                    <option *ngFor=\"#option of options;\" [value]=\"option.value\">{{option.label}}</option>\n                </select>\n            </div>\n            <ul class=\"ui-listbox-list\" *ngIf=\"!customContent\">\n                <li *ngFor=\"#option of options\" class=\"ui-listbox-item ui-corner-all\">\n                    {{option.label}}\n                </li>\n\n            </ul>\n            <ng-content *ngIf=\"customContent\"></ng-content>\n        </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [core_1.ElementRef])
                ], Listbox);
                return Listbox;
            })();
            exports_1("Listbox", Listbox);
        }
    }
});
//# sourceMappingURL=listbox.js.map