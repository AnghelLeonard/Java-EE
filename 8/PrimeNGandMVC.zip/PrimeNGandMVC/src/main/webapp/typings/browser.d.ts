/// <reference path="browser\ambient\chart\chart.d.ts" />
/// <reference path="browser\ambient\es6-shim\es6-shim.d.ts" />
/// <reference path="browser\ambient\jquery\jquery.d.ts" />
/// <reference path="browser\ambient\jqueryui\jqueryui.d.ts" />
